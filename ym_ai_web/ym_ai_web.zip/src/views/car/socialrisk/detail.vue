<template>
  <div class="social_container">
    111
  </div>
</template>

<script lang="ts" setup>

</script>

<style lang="scss" scoped>
.social_container {
  height: 100%;
  width: 100%;
  background-color: white;
}
</style>
