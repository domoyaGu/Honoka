// import request from '@/utils/request';

// // ————————————————————————————————————————————  其他接口 ————————————————————————————————————————————————

// /**
//  * 获取手机验证码
//  */
// export function getSmsCode(params) {
//   return request({
//     url: '/captcha/getCode',
//     method: 'get',
//     params
//   });
// }
