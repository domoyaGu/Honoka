/**
 * 设置状态类型声明
 */
export interface SystemState {
  roleList: string[];
  deptList: string[];
}
