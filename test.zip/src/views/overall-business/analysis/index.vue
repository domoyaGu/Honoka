<template>
  <div style="padding: 16px">
      <FilterWrap
        ref="filterWrap"
        :queryList="queryList"
        :form-span="8"
        @resetQuery="resetQuery"
        @handleQuery="handleQuery">
      </FilterWrap>
      <ListPage
        ref="listPage"
        :tabTheadAll="tabTheadAll"
        :dataList="dataList"
        :total="dataList.length"
        tabelTitle="人员列表"
        :operationWidth="220"
      >
        <template #operation="slot">
          <div>
            <el-button
              type="primary"
              link
              :icon="Search"
            >
              查看详情
            </el-button>
          </div>
        </template>
      </ListPage>
      <reportNewDialog ref="reportNewDialogRef"/>
      <ProcessDialog ref="processDialogRef"/>
  </div>
</template>

<script lang="ts" setup>
import router from '@/router';
import { Search, DocumentCopy, CopyDocument, Plus} from '@element-plus/icons-vue';
import ListPage from '@/components/ListPage/index.vue';
import { getPage } from '@/api/overall-business/report';

// 筛选表单
const queryList = ref({
  baSource: {title: '工号', content: "", type: 'input'},
  baStatus: {title: '姓名', content: "", type: 'input'},
  insuredName: {title: '手机号', content: "", type: 'input'},
  insuredPhone: {title: '部门', content: "", type: 'select', options: []},
  test: {title: '岗位', content: "", type: 'select', options: [{dictValue: '1', dictName: '前端开发'}]},
  carNumber: {title: '项目组', content: "", type: 'select', options: []},
  carVinNo: {title: '直属领导', content: "", type: 'select', options: []}
})

// 表头字段
const tabTheadAll = ref({
  no: '工号',
  name: '姓名',
  age: '年龄',
  phone: '手机号',
  dept: '部门',
  test: '岗位',
  project: '项目组',
  leader: '直属领导',
  work: '最近工作效率'
});

//————————————————————————————————————分页相关——————————————————————————————————
const loading = ref(true)
const dataList = ref([{
  no: '工号',
  name: '姓名',
  age: '年龄',
  phone: '手机号',
  dept: '部门',
  test: '岗位',
  project: '项目组',
  leader: '直属领导',
  work: '最近工作效率'
}])

</script>

<style lang="scss" scoped>
</style>
