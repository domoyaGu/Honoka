<template>
	<view class="user-container">
		<view class="header">
			<view>
				<span>顾韫琪</span>
				<span>/前端开发</span>
				<p>苏州远眸智能</p>
			</view>
			<u-avatar :src="src" shape="circle"></u-avatar>
		</view>
		<view class="money">
			<view class="money-tab">
				<p class="count">2812.21</p>
				<p class="label">昨日收益</p>
			</view>
			<view class="money-tab">
				<p class="count">2812.21</p>
				<p class="label">本周收益</p>
			</view>
			<view class="money-tab" style="border: none;">
				<p class="count">2812.21</p>
				<p class="label">累计收益</p>
			</view>
		</view>
		<view class="safe">
			<u-cell
				    title="账号与安全"
						label="修改密码,修改手机号码"
				    isLink
				    url="/pages/componentsB/tag/tag"
				></u-cell>
		</view>
		<view class="logout">
			<u-button style="color: orangered;">退出登录</u-button>
		</view>
	</view>
</template>

<script>
	export default {
		name:"user",
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss" scoped>
.user-container {
	// cell样式穿透
	.u-cell {
		background-color: white;
	}
	// 头
	.header {
		background: royalblue;
		display: flex;
		padding: 150rpx 50rpx 100rpx 50rpx;
		color: white;
    justify-content: space-between;
    align-items: center;
	}
	// 收益栏
	.money {
		display: flex;
		background-color: white;
		.money-tab {
			margin: 50rpx 0;
			width: 250rpx;
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			border-right: 1px #f1f1f1 solid;
			.count {
				font-size: 1.2rem;
				font-weight: bold;
			}
			.label {
				font-size: 0.9rem;
				color: #909193;
			}
		}
	}
	// 账号安全
	.safe {
		margin-top: 20rpx;
	}
	// 退出登录
	.logout {
		width: 100%;
		position: fixed;
		bottom: 120rpx;
	}
}
</style>