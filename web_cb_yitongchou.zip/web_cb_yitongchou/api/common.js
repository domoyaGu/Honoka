

/**
 * 获取网站title
 */
 export function getCompanyName() {
  return uni.$u.http.get('v6/user/company/getCompanyName')
}