export default {
    baseUrl: 'https://dev-api.yitongchou.com/api'
}
