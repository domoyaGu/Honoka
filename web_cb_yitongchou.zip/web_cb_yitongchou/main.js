import App from './App'

// #ifndef VUE3
import Vue from 'vue'
Vue.config.productionTip = false
App.mpType = 'app'
const app = new Vue({
    ...App
})
app.$mount()
// #endif

// #ifdef VUE3
// 状态存储
import * as Pinia from 'pinia';

import uviewPlus from './uni_modules/uview-plus/index.js'
import { createSSRApp } from 'vue'
import {initRequest} from '@/api/request.js'
export function createApp() {
  const app = createSSRApp(App)
  // 引入请求封装
  initRequest(app)
  
  app.use(uviewPlus).use(Pinia.createPinia())
  return {
    app,
	Pinia
  }
}
// #endif