import defprops from '../../libs/config/props';
export default {
    props: {

    }
}
