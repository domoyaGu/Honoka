<template>
	<view>
		<view>
			<user v-if="value == 3"></user>
		</view>
		<u-tabbar
		    :value="value"
				@change="change"
				:fixed="true"
				:placeholder="true"
				:safeAreaInsetBottom="true"
		>
			<u-tabbar-item
			    text="报价单"
			    icon="file-text"
			>
			</u-tabbar-item>
			<u-tabbar-item
			    text="投保单"
			    icon="bookmark"
			></u-tabbar-item>
			<u-tabbar-item
			    text="保险单"
			    icon="order"
			></u-tabbar-item>
			<u-tabbar-item
			    text="我的"
			    icon="account"
			></u-tabbar-item>
		</u-tabbar>
	</view>
</template>

<script setup>
import { ref } from "vue";
import { onLoad } from "@dcloudio/uni-app"
import user from '@/components/tabbers/user.vue'

const tabTexts = ['报价单', '投保单', '保险单', '我的']

const value = ref(0)

onLoad(()=>{
	uni.setNavigationBarTitle({
		title: tabTexts[value.value || 0]
	})
})

function change(index) {
	uni.setNavigationBarTitle({
		title: tabTexts[index]
	})
	value.value = index
}
</script>

<style lang="scss">
page {
	background-color: #F9F9F9;
}
</style>
