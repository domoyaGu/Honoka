<template>
	<view>
		
	</view>
</template>

<script setup>
	uni.$u.http.get('/user/login', {params: {userName: 'name', password: '123456'}}).then(res => {
		
	}).catch(err => {

	})
</script>

<style lang="scss">
	
</style>
