<template>
	<view class="login-container">
		<view class="login-logo">
			<image class="logo" src="/static/logo.png"></image>
		</view>
		<view class="login-form">
			<p class="login-title">密码登录</p>
			<u--form
				labelPosition="top"
				:model="loginForm"
				:rules="rules"
				ref="loginFormRef"
				>
				<u-form-item
					label=""
					prop="userName"
					borderBottom="true"
				>
					<u--input
						v-model="loginForm.userName"
						placeholder="请输入账号"
						border="bottom"
						clearable
					/>
				</u-form-item>
				<u-form-item
					label=""
					prop="password"
					borderBottom="true"
				>
					<u--input
						v-model="loginForm.password"
						type="password"
						placeholder="请输入密码"
						border="bottom"
						clearable
					/>
				</u-form-item>
			</u--form>
		</view>
		<u-button type="primary" :disabled="loginForm.userName == ''" @click="handleLogin">
			登录
		</u-button>
		<view class="forget-pwd">忘记密码?</view>
	</view>
</template>

<script setup>
import useStore from '@/store';
import { onMounted, ref } from "vue";
import { getCompanyName } from '@/api/common.js'

const { user } = useStore();

const loginForm = ref({
	sys: '统筹承保系统',
	companyDomain: 'szyuanmou',
	userName: '',
	password: ''
})
const rules = {
	userName: [
		{
			required: true, 
			message: '请输入账号',
			trigger: ['change','blur'],
		}
	],
	password: [
		{
			required: true, 
			message: '请输入密码',
			trigger: ['change','blur'],
		}
	]
}

const secretKey = 'YuaNm0u@04Z7./*#';
const regexIP = /^((25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))\.){3}(25[0-5]|2[0-4]\d|((1\d{2})|([1-9]?\d)))$/g;

// 网站title
function getTitle() {
  // 页面有未获取到document.title就渲染完成的情况
  getCompanyName().then(({ data }) =>{
    document.title = data.companyShowName
    state.htmlTitle = data.companyShowName
  })
}
// 获取二级域名（从URL获取公司租户号）
function getDomain() {
  const windowsLink = window.location.host.substring(0, location.host.indexOf(':'))
  // 开发模式 localhost ip 手动输入
  // console.log(window.location.hostname == 'localhost')
  // console.log(regexIP.test(windowsLink))
  if (window.location.hostname == 'localhost' || regexIP.test(windowsLink)) {
    // 展示输入框，手动输入
    // state.noDomain = true
  } else {
    // state.noDomain = false
    // 隐藏输入框，获取URL上的域名
    const companyDomain = window.location.hostname.substring(0, location.hostname.indexOf('.'))
    // console.log(companyDomain, '公司域名')
    state.loginForm.companyDomain = companyDomain
  }
}


// 表单ref
const loginFormRef = ref()

// 登录
function handleLogin() {
  loginFormRef.value.validate().then(res => {
		// 加载
		// showLoading()
		// if (state.passwordChecked) {
		//   // 存入cookie 加密密码
		//   setCookie(
		//     loginForm.value.userName,
		//     encryptByDES(loginForm.value.password, secretKey),
		//     7) // 保存7天
		//   setRememberPassword(1, 7)
		// } else {
			// clearCookie()
			// setRememberPassword(0, 7)
		// }
		// state.loading = true;

		user.login(loginForm.value)
			.then(({ data }) => {
				uni.$u.toast(data)
				// router.push({ path: state.redirect || '/', query: state.otherQuery });
				// router.push({ path: '/' });
				// state.loading = false;
			})
			.catch(() => {
				// state.loading = false;
			});
	});
}

onMounted(() => {
	// 获取二级域名
	getDomain();
	// 获取网站标题
	getTitle();
}) 

</script>

<style lang="scss">
	.login-container {
		display: flex;
		flex-direction: column;
		align-items: center;
		padding: 100rpx 80rpx;
		.login-logo {
			height: 360rpx;
			.logo {
				width: 200rpx;
				height: 200rpx;
			}
		}
		.login-form {
			width: 100%;
			
			.login-title {
				font-size: 36rpx;
				font-weight: bold;
			}
		}
		button {
			margin-top: 50rpx;
			border-radius: 15rpx;
		}
		.forget-pwd {
			cursor: pointer;
			margin-top: 18rpx;
			font-size: 28rpx;
			color: #1891FF
		}
	}
</style>
