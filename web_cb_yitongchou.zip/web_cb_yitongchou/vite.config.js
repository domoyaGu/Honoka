import { defineConfig } from "vite";
import uni from "@dcloudio/vite-plugin-uni";

/**
 * @type {import('vite').UserConfig}
 */

const path = require("path");
 
function resolve(dir) {
  return path.join(__dirname, dir);
}
 
const name = "web_cb_yitongchou";

export default defineConfig({
  build: {
    sourcemap: false, // App，小程序端源码调试，需要在 vite.config.js 中主动开启 sourcemap
  },

  plugins: [uni()],
  
  // 路径别名
configureWebpack: {
  name: name,
  resolve: {
	alias: {
	  "@": resolve("src"),
	  "@i": resolve("src/api"),
	  "@c": resolve("src/components"),
	  "@a": resolve("src/assets"),
	  "@s": resolve("src/styles"),
	  "@u": resolve("src/utils"),
	  "@v": resolve("src/pages"),
	},
  },
},
  
});
