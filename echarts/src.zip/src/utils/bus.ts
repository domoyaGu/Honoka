// 定义全局事件

// mitt事件总线
import mitt from 'mitt';
const emitter = mitt();
export default emitter;
