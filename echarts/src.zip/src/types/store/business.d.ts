/**
 * 类型声明
 */
export interface BusinessState {
  qiyuesuoLink: string;
  loading: boolean;
}
