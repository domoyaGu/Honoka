export interface UserState {
  token: string;
  userId: string;
  userInfo: object,
  allEnum: object,
  roles: string[];
  perms: string[];
  selectMap: object,
  area: object[]
}
